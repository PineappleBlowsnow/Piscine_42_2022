int	ft_strlen(char *str)
{
	char	*end;

	end = str;
	while (*end)
		end++;
	return (end - str);
}

int	ft_isspace(char c)
{
	if (c == ' ' || c == '\f' || c == '\n'
		|| c == '\r' || c == '\t' || c == '\v')
		return (1);
	else
		return (0);
}

int	ft_base_is_not_ok(char *base)
{
	int	i;
	int	j;

	i = 0;
	if (*base == '\0' || ft_strlen(base) == 1)
		return (1);
	while (base[i])
	{
		if (base[i] == '+' || base[i] == '-' || ft_isspace(base[i]))
			return (1);
		j = i + 1;
		while (base[j])
		{
			if (base[i] == base[j])
				return (1);
			j++;
		}
		i++;
	}
	return (0);
}

int	ft_find_index(char c, char *base)
{
	int	i;

	i = 0;
	while (i < ft_strlen(base))
	{
		if (c == base[i])
			return (i);
		i++;
	}
	return (-1);
}

int	ft_atoi_base(char *nbr, char *base_from)
{
	int	count_minus;
	int	nb;

	count_minus = 1;
	while (ft_isspace(*nbr))
		nbr++;
	while ((*nbr == '+') || (*nbr == '-'))
	{
		if (*nbr == '-')
			count_minus *= -1;
		nbr++;
	}
	nb = 0;
	while (ft_find_index(*nbr, base_from) != -1)
	{
		nb = nb * ft_strlen(base_from) + count_minus * (ft_find_index(*nbr, base_from));
		nbr++;
	}
	return (nb);
}

char*	ft_putnbr_base(int nb, char *base_to)
{
	long long int	nbr1;
	char			c;
    char res[32];

	nbr1 = nb;
	if (nbr1 < 0)
	{
		nbr1 = -nbr1;
		res[0]='-';
	}
	if (nbr1 / ft_strlen(base_to))
		ft_putnbr_base(nbr1 / ft_strlen(base_to), base_to);
	res[] = *(base_to + nbr1 % ft_strlen(base_to));
}

char *ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	if(ft_base_is_not_ok(base_from)||ft_base_is_not_ok(base_to))
		return (NULL);
    
	
}