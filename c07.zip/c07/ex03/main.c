#include<stdio.h>
#include<stdlib.h>

char *ft_strjoin(int size, char **strs, char *sep);

int main()
{
    char *p;
    char *sep;
    sep="2c";
    char *str1;
    str1="abdc";
    //char *str2;
    //str2="sdf";
    //char *str3;
    //str3="cgy";
    //char *str4;
    //str4="dfd";
    char *test[]={str1};
    p=ft_strjoin(1,test,sep);
    printf("hahah\n");
    printf("%s\n",p);
    printf("hahah\n");
    free(p);
}