#include<stdlib.h>

int ft_strcomp(char *s1, char *s2)
{
    int i;

    i=0;
    while(s1[i]&&s1[i]==s2[i])
        i++;
    return (s1[i]-s2[i]);
}

int ft_strlen(char *src)
{
    char *start;
    start = src;
    while (*src)
        src++;
    return (src - start);
}

char	*ft_strcat(char *dest, char *src)
{
	char	*st;

	st = dest;
	while (*dest)
		dest++;
	while (*src)
	{
		*dest = *src;
		dest++;
		src++;
	}
	return (st);
}

char *ft_strjoin(int size, char **strs, char *sep)
{
    char *res;
    int i;
    int num;

    if(size==0)
        return (NULL);
    i=0;
    num=0;
    while(i<size)
    {
        num+=ft_strlen(*(strs+i));
        i++;
    }
    num=num+(size-1)*ft_strlen(sep)+1;

    res=malloc(sizeof(*res)*num);
    res[0]='\0';
    i=0;
    while(i<size)
    {
       
        res=ft_strcat(res,*(strs+i));
        res=ft_strcat(res,sep);
        i++;
    }
    res[num]='\0';
    return (res);
}