#include <stdlib.h>

int ft_strlen(char *src)
{
    char *start;
    start = src;
    while (*src)
        src++;
    return (src - start);
}

char *ft_strdup(char *src)
{
    char *st;
    int i;

    st = malloc(sizeof(*st) * (ft_strlen(src) + 1));
    if (!st)
        return (NULL);
    i = 0;
    while (src[i])
    {
        st[i] = src[i];
        i++;
    }
    st[i] = '\0';
    return (st);
}
