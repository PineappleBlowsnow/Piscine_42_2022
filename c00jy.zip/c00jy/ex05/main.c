void    ft_print_comb(void);
int main()
{
    ft_print_comb();
}