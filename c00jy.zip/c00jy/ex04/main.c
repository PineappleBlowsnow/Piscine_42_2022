void ft_is_negative(int n);

int main(){
    ft_is_negative(5); 
    ft_is_negative(-2); 
    ft_is_negative(0);
    return (0); 
}