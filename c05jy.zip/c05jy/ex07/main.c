#include <stdio.h>

int ft_find_next_prime(int nb);
int main()
{
    printf("%d\n",ft_find_next_prime(-10));
}