#include <stdio.h>
int ft_ten_queens_puzzle(void);

int main()
{
    printf("%d\n",ft_ten_queens_puzzle());
}
