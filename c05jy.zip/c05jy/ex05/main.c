#include<stdio.h>

int ft_sqrt(int nb);  

int main()
{
    printf("%d\n",ft_sqrt(-1));
   printf("%d\n",ft_sqrt(0));
   printf("%d\n",ft_sqrt(1));
   printf("%d\n",ft_sqrt(2));
    printf("%d\n",ft_sqrt(3));
   printf("%d\n",ft_sqrt(4));
   printf("%d\n",ft_sqrt(25));
   printf("%d\n",ft_sqrt(36));
    printf("%d\n",ft_sqrt(196));
   printf("%d\n",ft_sqrt(17));
   printf("%d\n",ft_sqrt(9));
   printf("%d\n",ft_sqrt(10));
}